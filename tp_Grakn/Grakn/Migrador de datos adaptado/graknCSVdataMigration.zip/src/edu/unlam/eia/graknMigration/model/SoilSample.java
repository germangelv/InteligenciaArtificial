package edu.unlam.eia.graknMigration.model;

import java.util.Map;

import edu.unlam.eia.graknMigration.utils.CSVReaderUtil;

public class SoilSample {
	
	static String identifier_key 			  = "sample"             ;
	static String ce_key 					  = "ce"			     ;
	static String organic_matter_percent_key = "organicMatterPercent";
	static String soil_ph_key         		  = "ph"			     ;
	static String soil_nitrogen_key   		  = "nitrogen"		     ;
	static String soil_phosphorus_key 		  = "phosphorus"		 ;
	static String soil_potassium_key  		  = "potassium"			 ;
	static String clay_percent_key    		  = "clayPercent"	     ;

	public long identifier;
	public double ce;
	public double organicMatterPercent;
	public double soilPh;
	public double soilNitrogen;
	public double soilPhosphorus;
	public double soilPotassium;
	public double clayPercent;

	public SoilSample(Map<String,String> map) {
		this.identifier           = CSVReaderUtil.parseToLong(map.get(identifier_key));
		this.ce                  = CSVReaderUtil.parseToDouble(map.get(ce_key));
		this.organicMatterPercent = CSVReaderUtil.parseToDouble(map.get(organic_matter_percent_key));
		this.soilPh 			   = CSVReaderUtil.parseToDouble(map.get(soil_ph_key)) ;
		this.soilNitrogen 		   = CSVReaderUtil.parseToDouble(map.get(soil_nitrogen_key)) ;
		this.soilPhosphorus 	   = CSVReaderUtil.parseToDouble(map.get(soil_phosphorus_key));
		this.soilPotassium        = CSVReaderUtil.parseToDouble(map.get(soil_potassium_key)) ;
		this.clayPercent          = CSVReaderUtil.parseToDouble(map.get(clay_percent_key)) ;
	}
}
