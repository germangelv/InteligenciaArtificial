package edu.unlam.eia.graknMigration;

import edu.unlam.eia.graknMigration.graknMigrators.PlantationMigrator;
import edu.unlam.eia.graknMigration.graknMigrators.SoilSampleMigrator;
import edu.unlam.eia.graknMigration.utils.CSVReaderUtil;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import ai.grakn.Grakn;
import ai.grakn.GraknSession;

public class Main {

	static GraknSession session;
	
	public static void main(String[] args) {
		
		session = Grakn.session(Grakn.DEFAULT_URI, "watson_fertilizacion");
		
		String basePath = "files" + File.separator;
		String plantationPath = basePath + "plantation_csv_data.csv";
		String samplePath     = basePath + "sample_csv_data.csv";
		
	
		CSVReaderUtil plantationUtil = new CSVReaderUtil(plantationPath);
		List<Map<String,String>> plantationList = plantationUtil.parse();
		
		
		PlantationMigrator plantationMigrator = new PlantationMigrator(session);
		
		plantationMigrator.migrate(plantationList);
		
		CSVReaderUtil soilSampleUtil = new CSVReaderUtil(samplePath);
		List<Map<String,String>> soilSampleList = soilSampleUtil.parse();
		
		SoilSampleMigrator soilMigrator = new SoilSampleMigrator(session);
		soilMigrator.migrate(soilSampleList);
		
		session.close();
		
	}

}
