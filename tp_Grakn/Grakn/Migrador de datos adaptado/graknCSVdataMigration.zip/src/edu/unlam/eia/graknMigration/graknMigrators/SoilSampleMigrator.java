package edu.unlam.eia.graknMigration.graknMigrators;

import static ai.grakn.graql.Graql.var;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import ai.grakn.GraknSession;
import ai.grakn.GraknTx;
import ai.grakn.GraknTxType;
import ai.grakn.graql.QueryBuilder;
import edu.unlam.eia.graknMigration.model.SoilSample;

public class SoilSampleMigrator {
	GraknSession session;
	GraknTx tx;
	
	public SoilSampleMigrator(GraknSession session) {
		this.session = session;
	}
	
	public void migrate(List<Map<String,String>> list) {
		
		 this.tx = this.session.open(GraknTxType.BATCH);
		
		list
		.stream()
		.map(mapToItem)
		.collect(Collectors.toList())
		.forEach(loadToGraknServer);
		
		this.tx.commit();
	}
	
	public Function<Map<String,String>, SoilSample > mapToItem = (item) -> {
	   
		  return new SoilSample(item);
	
	};
	
	public Consumer<SoilSample> loadToGraknServer = (item) -> {
		
		QueryBuilder qb = this.tx.graql();
	    
		qb.insert(
				var()
				.isa("suelo")
				.has("idMuestra",item.identifier)
				.has("conductividad_electrica", item.ce)
				.has("nivel_materia_organica",item.organicMatterPercent)
				.has("nivel_ph",item.soilPh)
				.has("nitrogeno_suelo",item.soilNitrogen)
				.has("fosforo_suelo",item.soilPhosphorus)
				.has("potasio_suelo", item.soilPotassium)
				.has("textura",item.clayPercent)
				)
		.execute();
		
	};
}
