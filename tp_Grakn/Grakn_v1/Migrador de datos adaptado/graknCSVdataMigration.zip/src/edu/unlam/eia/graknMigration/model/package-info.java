/**
 * 
 */
/**
 * @author martin
 *
 */
package edu.unlam.eia.graknMigration.model;