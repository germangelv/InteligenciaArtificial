package edu.unlam.eia.graknMigration.model;

import java.util.Map;

import edu.unlam.eia.graknMigration.utils.CSVReaderUtil;

public class Plantation {

	static String pid_key              = "pid"   		 ;  
	static String name_key 	           = "name"  		 ;
	static String ph_tolerance_min_key = "phToleranceMin";
	static String ph_tolerance_max_key = "phToleranceMax";
	static String plant_nitrogen_key   = "N" 		  	 ;
	static String plant_phosphorus_key = "P" 		  	 ;
	static String plant_potassium_key  = "K" 	      	 ;

	public long pid; 
	public String name;
	public double phToleranceMin;
	public double phToleranceMax;
	public double plantNitrogen;
	public double plantPhosphorus;
	public double plantPotassium;

	public Plantation (){

	}

	public Plantation (Map<String,String> map) {

		this.pid             = CSVReaderUtil.parseToLong(map.get(pid_key));
		this.name            = map.get(name_key);
		this.phToleranceMin  = CSVReaderUtil.parseToDouble(map.get(ph_tolerance_min_key));
		this.phToleranceMax  = CSVReaderUtil.parseToDouble(map.get(ph_tolerance_max_key));
		this.plantNitrogen   = CSVReaderUtil.parseToDouble(map.get(plant_nitrogen_key));
		this.plantPhosphorus = CSVReaderUtil.parseToDouble(map.get(plant_phosphorus_key));
		this.plantPotassium  = CSVReaderUtil.parseToDouble(map.get(plant_potassium_key)); 
	}
	    
}
