package edu.unlam.eia.graknMigration.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.cassandra.thrift.Cassandra.AsyncProcessor.system_add_column_family;

public class CSVReaderUtil {
	
	static String CSV_SEPARATOR = ";";
	String filePath;
	String header;
	
	public String getHeader() {
		return header;
	}

	public CSVReaderUtil(String filePath) {
		this.filePath = filePath;
	}
	
	public List<Map<String, String>> parse(){
		return this.processInputFile(filePath);
	}
	
	public static double parseToDouble(String str) {
		return Double.parseDouble(str);
	}
	
	public static long parseToLong(String str) {
		return Long.parseLong(str);
	}
	
	private List<Map<String, String>> processInputFile(String inputFilePath) {

	    List<Map<String, String>> inputList = new ArrayList<>();

	    try{

	      File inputF = new File(inputFilePath);

	      InputStream inputFS = new FileInputStream(inputF);

	      BufferedReader br = new BufferedReader(new InputStreamReader(inputFS));

	      this.header = br.readLine();
	      
	      inputList = br
	    		  .lines()
	    		  .map(mapToItem)
	    		  .collect(Collectors.toList());

	      br.close();

	    } catch (IOException e) {
	    	System.out.println(e);
	    }

	    return inputList ;

	}
	
	public Function<String, Map<String,String>> mapToItem = (line) -> {

		  String[] tupleFields = line.split(CSV_SEPARATOR);// a CSV has comma separated lines

		  Map<String,String> item = new Hashtable();
		  
		  String[] headerFields = this.header.split(CSV_SEPARATOR);
		 
		  for (int i = 0; i < tupleFields.length; i++) {
				String value  = tupleFields[i];
				String header = headerFields[i];
				item.put(header, value);
				System.out.println(header);
				System.out.println(value);
				
		  }
		  
		  return item;

		};

}
