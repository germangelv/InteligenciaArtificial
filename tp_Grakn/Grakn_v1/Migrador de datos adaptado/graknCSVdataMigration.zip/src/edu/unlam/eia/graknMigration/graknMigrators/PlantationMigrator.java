package edu.unlam.eia.graknMigration.graknMigrators;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import ai.grakn.GraknSession;
import ai.grakn.GraknTx;
import ai.grakn.GraknTxType;
import ai.grakn.graql.QueryBuilder;
import edu.unlam.eia.graknMigration.model.Plantation;
import static ai.grakn.graql.Graql.*;

public class PlantationMigrator {

	GraknSession session;
	GraknTx tx;
	
	public PlantationMigrator(GraknSession session) {
		this.session = session;
	}
	
	public void migrate(List<Map<String,String>> list) {
		
		 this.tx = this.session.open(GraknTxType.BATCH);
		
		list
		.stream()
		.map(mapToItem)
		.collect(Collectors.toList())
		.forEach(loadToGraknServer);
		
		this.tx.commit();
		this.tx.close();
	}
	
	public Function<Map<String,String>, Plantation > mapToItem = (item) -> {
	   
		  return new Plantation(item);
	
	};
	
	public Consumer<Plantation> loadToGraknServer = (item) -> {
		
		QueryBuilder qb = this.tx.graql();
	    

		qb.insert(
				var()
				.isa("cultivo")
				.has("idCultivo",item.pid)
				.has("name", item.name)
				.has("ph_min",item.phToleranceMin)
				.has("ph_max",item.phToleranceMax)
				.has("nitrogeno_cultivo",item.plantNitrogen)
				.has("fosforo_cultivo",item.plantPhosphorus)
				.has("potasio_cultivo",item.plantPotassium)
				)
		.execute();
		
	};
}
